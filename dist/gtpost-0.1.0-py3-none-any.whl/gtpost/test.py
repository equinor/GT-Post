import numpy as np
import xarray as xr

from gtpost.analyze.classifications import ArchEl, SubEnv
from gtpost.io.export import ENCODINGS

dataset = xr.open_dataset(
    r"n:\Projects\11209000\11209074\B. Measurements and calculations\test_results\Sobrarbe_048_Reference\Sobrarbe_048_Reference - coarse-sand_sed_and_obj_data_v2.nc"
)
dataset["subenv"].attrs["encoding"] = [i.value for i in SubEnv.__iter__()]
dataset["subenv"].attrs["names"] = [i.name for i in SubEnv.__iter__()]
dataset["archel"].attrs["encoding"] = [i.value for i in ArchEl.__iter__()]
dataset["archel"].attrs["names"] = [i.name for i in ArchEl.__iter__()]
dataset.to_netcdf(
    r"n:\Projects\11209000\11209074\B. Measurements and calculations\test_results\Sobrarbe_048_Reference\Sobrarbe_048_Reference - coarse-sand_sed_and_obj_data_v2.nc",
    engine="h5netcdf",
    encoding=ENCODINGS,
)
